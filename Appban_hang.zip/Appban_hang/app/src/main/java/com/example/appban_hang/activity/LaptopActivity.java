package com.example.appban_hang.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.appban_hang.R;

public class LaptopActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_laptop);
    }
}