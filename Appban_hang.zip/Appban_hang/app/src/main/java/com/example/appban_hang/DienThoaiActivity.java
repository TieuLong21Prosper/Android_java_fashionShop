package com.example.appban_hang;

import android.app.Activity;

public class DienThoaiActivity extends Activity {
}
