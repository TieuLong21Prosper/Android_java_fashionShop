package com.example.appban_hang.utils;

import com.example.appban_hang.model.GioHang;

import java.util.List;

public class Utils {
    public static final String BASE_URL = "http://192.168.1.6/data_android_banhang/";
    public static List<GioHang> manggiohang;
}
