package com.example.appban_hang.Interface;

import android.view.View;

public interface IImageClickListener {
    void onImageClick(View view, int pos, int giatri);

}
