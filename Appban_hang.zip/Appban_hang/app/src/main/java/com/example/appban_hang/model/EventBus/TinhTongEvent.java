package com.example.appban_hang.model.EventBus;

public class TinhTongEvent {
}
